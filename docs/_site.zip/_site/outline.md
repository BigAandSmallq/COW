# Diffusion in Diffusion

teaser fig (可以是动图)

## abstract
abstract

## Preliminares
diffusion phenomenon
## method flow chat


## more results